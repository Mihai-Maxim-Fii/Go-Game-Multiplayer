#include <iostream>
#include <string.h>
#include <SFML/Graphics.hpp>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#define PORT 4444
using namespace std;
int main()
{   sf::RenderWindow window(sf::VideoMode(200, 200), "SFML works!");
    sf::CircleShape shape(100.f);
    int x=0;
    shape.setFillColor(sf::Color::Green);
        window.clear();
        window.draw(shape);
        window.display();

    int clientSocket, ret;
	struct sockaddr_in serverAddr;
	char buffer[1024];

	clientSocket = socket(AF_INET, SOCK_STREAM, 0);
	if(clientSocket < 0){
		printf("Eroare la socket.\n");
		exit(1);
	}

	memset(&serverAddr, '\0', sizeof(serverAddr));
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(PORT);
	serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1");

	ret = connect(clientSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr));
	if(ret < 0){
		printf("Eroare la connect.\n");
		exit(1);
	}
	printf("Conexiune reusita.\n");
	while(window.isOpen()){
        bool change=false;
         while(!change){
        if(sf::Mouse::isButtonPressed(sf::Mouse::Left))
        {
            if(x==0){shape.setFillColor(sf::Color::Red);x=1;}
            else
            {shape.setFillColor(sf::Color::Green);x=0;}
            change=true;
            window.clear();
            window.draw(shape);
            window.display();
        }
    }
		printf("Client:");
		scanf("%s", &buffer[0]);
		send(clientSocket, buffer, strlen(buffer), 0);

		if(strcmp(buffer, "quit") == 0){
			close(clientSocket);
			printf("Te-ai deconectat de la server.\n");
			exit(1);
		}

		if(recv(clientSocket, buffer, 1024, 0) < 0){
			printf("Nu s-au receptionat datele de la server.\n");
		}else{
			printf("Server: %s\n", buffer);
		}
        sf::Event event;
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
                window.close();
        }

        window.clear();
        window.draw(shape);
        window.display();
	}

    
}